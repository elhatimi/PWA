<?php



include('connectDB.inc');
/*------------------------------------*/
/* Fichier appelant la base de donnée */
/*------------------------------------*/
include('connect.php');
/*-------------------------------*/
$ValidityUserName=0;
session_start();
if (isset($_SESSION['username']) | isset($_POST['username']) ) {
    if (isset($_SESSION['username']) && isset($_SESSION['password'])){
        if ($_SESSION['username'] !== "" && $_SESSION['password'] !== "") {

            $username = securite_bdd($_SESSION['username']);
            $password = securite_bdd($_SESSION['password']);
            $_SESSION['username'] = $username;
            $requete = "SELECT count(*) FROM user WHERE UserName = '" . $username . "' AND PassWord = '" . $password . "' AND ValueConnect='1' ";
            $exec_requete = mysqli_query($linkPWA_Msg, $requete) or die($requete . ' ' . mysqli_error($linkPWA_Msg));
            $reponse = mysqli_fetch_array($exec_requete);
            $count = $reponse['count(*)'];

            if ($count != 0) {
                $ValidityUserName = 1;
                $idUserPWA_Msg = $PWA_MsgBdd->query("SELECT * FROM user  WHERE UserName = '" . $username . "' ");
                $idUser = $idUserPWA_Msg->fetch();
                $idUser = $idUser['IdUser'];
                $idUserPWA_Msg->closeCursor();
            } else {
                session_destroy();
                session_start();
            };
        } else {
            session_destroy();
            session_start();
        };
    } else {
        if (isset($_POST['username']) && isset($_POST['password'])) {
            $username = securite_bdd($_POST['username']);
            $password = securite_bdd($_POST['password']);
            $_SESSION['username'] = $username;
            if ($username !== "" && $password !== "") {
                $requete = "SELECT count(*) FROM user WHERE UserName = '" . $username . "' AND PassWord = '" . $password . "' ";
                $exec_requete = mysqli_query($linkPWA_Msg, $requete) or die($requete . ' ' . mysqli_error($linkPWA_Msg));
                $reponse = mysqli_fetch_array($exec_requete);
                $count = $reponse['count(*)'];
                if ($count != 0) {
                    $_SESSION['username'] = $username;
                    $_SESSION['password'] = $password;
                    $ValidityUserName = 1;
                    $idUserPWA_Msg = $PWA_MsgBdd->query("SELECT * FROM user  WHERE UserName = '" . $username . "' ");
                    $idUser = $idUserPWA_Msg->fetch();
                    $idUser = $idUser['IdUser'];
                    $idUserPWA_Msg->closeCursor();
                    $query = "UPDATE user SET ValueConnect='1' WHERE UserName = '" . $username . "'";
                    $result = mysqli_query($linkPWA_Msg, $query) or die($query . ' ' . mysqli_error($linkPWA_Msg));
                }
            }
        }
    };
}
else{
    session_destroy();
    session_start();
};
include('construct.php');

?>