<?php

include('session.php');

    $MsgConvers=InitDb($_SESSION['username'])['RefreshConvers'];
    echo json_encode($MsgConvers);


?>