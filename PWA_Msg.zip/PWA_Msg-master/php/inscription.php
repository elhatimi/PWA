<?php


include('session.php');
if (
    !empty($_POST['username']) &
    !empty($_POST['password'])
   ){

    $username = securite_bdd($_POST['username']);
    $password = securite_bdd($_POST['password']);

    if ($username !== "" && $password !== "") {
        $requete = "SELECT count(*) FROM user WHERE UserName = '" . $username . "'";
        $exec_requete = mysqli_query($linkPWA_Msg , $requete);
        $reponse = mysqli_fetch_array($exec_requete);
        $count = $reponse['count(*)'];
        if (empty ($count)) {
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            $query = "INSERT INTO user (idUser,UserName,PassWord,ValueConnect) values (null,'" . $username . "','" . $password . "','1')";
            $result = mysqli_query($linkPWA_Msg, $query) or die($query . ' ' . mysqli_error($linkPWA_Msg ));
            header('Location: ../index.php');
        } else {
            header('Location: ../index.php');
               };
    } else {
        header('Location: ../index.php');
           };
} else {
    header('Location: ../index.php');
};


?>