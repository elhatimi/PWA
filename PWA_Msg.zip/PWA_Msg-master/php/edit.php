<?php

include('connectDB.inc');
include('connect.php');
include('construct.php');

if (
    isset($_GET['Msg_Msg'])
  & isset($_GET['Contact_Msg'])
  & isset($_GET['id_Convers'])
  & isset($_GET['IdTemp_Msg'])
   )
{
    if (
         securite_bdd($_GET['id_Convers']) <> 0
        & securite_bdd($_GET['IdTemp_Msg'])<> 0
         & securite_bdd($_GET['IdTemp_Msg'])<> '0'
       )
    {

        $Msg_Msg = securite_bdd($_GET['Msg_Msg']);
        $iduser = securite_bdd(searchbyName($_GET['Contact_Msg']));
        $id_Convers = securite_bdd($_GET['id_Convers']);
        $IdTemp_Msg = securite_bdd($_GET['IdTemp_Msg']);

        $query = "INSERT into msg(idUser,idConvers,Msg,IdTemp_Msg) values (\"$iduser\",\"$id_Convers\",\"$Msg_Msg\",\"$IdTemp_Msg\")";
        $result = mysqli_query($linkPWA_Msg, $query) or die($query . ' ' . mysqli_error($linkPWA_Msg));

    }
}
?>