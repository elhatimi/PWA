<?php

include('connectDB.inc');
include('connect.php');
include('construct.php');
/*
if (
      isset($_GET['IdTemp_UserConvers'])
    & isset($_GET['id_Convers'])
    & isset($_GET['id_User'])
   )
{
    if (
        securite_bdd($_GET['id_Convers']) <> 0
        & securite_bdd($_GET['IdTemp_UserConvers'])<> 0
    ) {
*/
        $IdTemp_UserConvers = securite_bdd($_GET['IdTemp_UserConvers']);
        $id_Convers =securite_bdd( $_GET['id_Convers']);
        $iduser = securite_bdd($_GET['id_User']);
        $iduser = securite_bdd(searchbyName($iduser));

        $querys = "INSERT into conversuser(idConvers,idConversUser,idUser) values (\"$id_Convers\",\"$IdTemp_UserConvers\",\"$iduser\")";
        $results = mysqli_query($linkPWA_Msg, $querys) or die($querys . ' ' . mysqli_error($linkPWA_Msg));
 /*   }
}*/
?>