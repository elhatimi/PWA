<?php
session_start();
include('connectDB.inc');
include('connect.php');
include('construct.php');

$iduser=searchbyName($_GET['Contact_Msg']);






$query="INSERT into msg(idUser,idConvers,Msg,IdTemp_Msg) values (\"$iduser\",\"$id_Convers\",\"$Msg_Msg\",\"$IdTemp_Msg\")";
$result=mysqli_query($linkPWA_Msg,$query) or die($query.' '.mysqli_error($linkPWA_Msg));


?>