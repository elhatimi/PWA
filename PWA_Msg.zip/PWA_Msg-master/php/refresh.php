<?php

include('session.php');

    $message=InitDb($_SESSION['username'])['Message'];
    echo json_encode($message);


?>