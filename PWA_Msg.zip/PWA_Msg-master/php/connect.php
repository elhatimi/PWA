<?php



/*---Utilisation Classique-------*/
$PWA_MsgHost="mysql-jeanritter.alwaysdata.net";
$PWA_MsgUser="214494_msg";
$PWA_MsgPasswd="hokmah42";
$PWA_MsgBd="jeanritter_msg";
/*
$PWA_MsgHost = "localhost";
$PWA_MsgUser = "root";
$PWA_MsgPasswd = "";
$PWA_MsgBd = "msg";
*/
$linkPWA_Msg = mysqli_connect($PWA_MsgHost,$PWA_MsgUser,$PWA_MsgPasswd,$PWA_MsgBd);

if(mysqli_connect_errno($linkPWA_Msg))
{
    echo "Erreur ".mysqli_connect_error($linkPWA_Msg);
}

/*-----------POO-----------------*/
try
{
    // connexion à MySQL  //
    $PWA_MsgBdd = new PDO(
        'mysql:host='.$PWA_MsgHost.';
         	      dbname='.$PWA_MsgBd.';
         	     charset=utf8',
        $PWA_MsgUser,
        $PWA_MsgPasswd
    );
}
catch (Exception $e)
{
    // Affichage d'une erreur en cas d'echec  //
    die('Erreur : ' . $e->getMessage());
}


?>