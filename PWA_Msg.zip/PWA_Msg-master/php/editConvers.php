<?php

include('connectDB.inc');
include('connect.php');
include('construct.php');

/*
if (
      isset($_GET['IdTemp_Convers'])
    & isset($_GET['id_Convers'])
    & isset($_GET['StatuConvers'])
    & isset($_GET['Nb_Contact'])
    & isset($_GET['Nb_Msg'])
   )
{*/

        $IdTemp_Convers = securite_bdd($_GET['IdTemp_Convers']);
        $id_Convers = securite_bdd($_GET['id_Convers']);
        $StatuConvers = securite_bdd($_GET['StatuConvers']);
        $Nb_Contact =securite_bdd($_GET['Nb_Contact']);
        $Nb_Msg = securite_bdd($_GET['Nb_Msg']);

    if ($Nb_Contact<>0)
    {
/*
        $Yask="SELECT  count(*) FROM conversuser WHERE idConvers= ".$id_Convers."  " ;
        $queryaskyl=$Yask ;
        $resultaskyl=mysqli_query($linkPWA_Msg,$queryaskyl)  or die($queryaskyl.' '.mysqli_error($linkPWA_Msg)) ;
        $resultTempy=mysqli_fetch_array($resultaskyl);
        $Nb_Contact= $resultTempy['count(*)'];
*/

        $query = "INSERT into convers(idConvers,Name,NbContact,NbMsg) values (\"$id_Convers\",\"$IdTemp_Convers\",\"$Nb_Contact\",\"$Nb_Msg\")";
        $result = mysqli_query($linkPWA_Msg, $query) or die($query . ' ' . mysqli_error($linkPWA_Msg));
    }
//}

?>