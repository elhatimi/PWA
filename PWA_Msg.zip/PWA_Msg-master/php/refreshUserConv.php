<?php

include('session.php');

    $MsgUserConvers=InitDb($_SESSION['username'])['RefreshUserConvers'];
    echo json_encode($MsgUserConvers);


?>