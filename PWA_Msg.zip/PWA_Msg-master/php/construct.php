<?php

class User
{
    var $idUser;
    var $UserName;
    var $ValueConnect;
    function __construct(
        $idUser,
        $UserName,
        $ValueConnect
    )
    {
        $this->idUser = $idUser;
        $this->UserName = $UserName;
        $this->ValueConnect = $ValueConnect;
    }
}
class idUser
{
    var $idUser;
    function __construct(
        $idUser
    )
    {
        $this->idUser = $idUser;
    }
}
class ConversUser
{
    var $idConversUser;
    var $idUser;
    var $idConvers;
    function __construct(
        $idConversUser,
        $idUser,
        $idConvers
    )
    {
        $this->idConversUser = $idConversUser;
        $this->idUser = $idUser;
        $this->idConvers= $idConvers;
    }
}
class Msg
{
    var $idMsg;
    var $idUser;
    var $idConvers;
    var $Msg;
    var $Date;
    var $IdTemp_Msg;
    function __construct(
         $idMsg,
         $idUser,
         $idConvers,
         $Msg,
         $Date,
         $IdTemp_Msg
)
    {
        $this->idMsg = $idMsg;
        $this->idUser = $idUser;
        $this->idConvers = $idConvers;
        $this->Msg = $Msg;
        $this->Date = $Date;
        $this->IdTemp_Msg=$IdTemp_Msg;
    }
}
class Convers
{
    var $idConvers;
    var $Name;
    var $NbContact;
    var $NbMsg;
    function __construct(
        $idConvers,
        $Name,
        $NbContact,
        $NbMsg
    )
    {
        $this->idConvers = $idConvers;
        $this->Name = $Name;
        $this->NbContact = $NbContact;
        $this->NbMsg = $NbMsg;
    }
}
/*********************************************************/
function connexion(){

    global $ValidityUserName ;

    if ($ValidityUserName==0)
    {
        $modul='<form action="index.php" method="POST">
                
                <fieldset><legend class="hide">Identification</legend>
                <div class="control-group">
                   <div class="form-group floating-label-form-group controls mb-0 pb-2">
                     <label class="hide">Utilisateur:</label>
                     <input type="text" name="username" id="username" required  pattern="[a-zA-Z0-9 ]*" minlength="3" maxlength="10" placeholder="Nom Utilisateur" >
                   </div>
                </div>
                <br/>
                <div class="control-group">
                   <div class="form-group floating-label-form-group controls mb-0 pb-2">
                    <label class="hide">Mot de passe:</label>
                    <input type="password" name="password" id="password" required pattern="[a-zA-Z0-9 ]*" minlength="3" maxlength="10" placeholder="Mot de passe">
                   </div>
                </div>
                <br/>
                <br/>
                    <br/><div class="form-group">
                      <button class="btn btn-primary btn-xl" type="submit" id="submit" >
                     CONNEXION
                      </button>
                   </div>
                <br/>                    
                </fieldset> 
                </form> ';
    }
    else
    {
        /*
        global $username ;
        $modul='<form action="php/disconnect.php" method="POST">
                <fieldset>
             //   <legend>'.$username.'</legend>
                <input type="submit" name="submit" value="deconnexion">
                </fieldset> 
                </form>';
        */
    };

    return $modul;
}
/*********************************************************/
function ConstructInitDialog($username){
    $idUser=0;
    global $linkPWA_Msg;
    $query="SELECT user.idUser AS idUser FROM user WHERE user.username='".$username."'";
    $result=mysqli_query($linkPWA_Msg,$query) or die($query.' '.mysqli_error($linkPWA_Msg));
    while($var=mysqli_fetch_assoc($result)){extract($var);
        $listeidUse[$idUser]= new idUser($idUser);};



    return $idUser;
}
/*********************************************************/
function Convers($id){
    global $linkPWA_Msg;

    $ask="SELECT  *  FROM convers WHERE idConvers='".$id."' " ;
    $queryask=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultask=mysqli_query($linkPWA_Msg,$queryask) or die($queryask.' '.mysqli_error($linkPWA_Msg));
    while($varAsk=mysqli_fetch_assoc($resultask))
    {
        extract($varAsk);
        $listeUser[$idConvers]= new Convers(
            $idConvers,
            $Name,
            $NbContact,
            $NbMsg
        );
    }

    $recap =array(
        'idConvers' => $idConvers,
        'Name' => $Name,
        'NbContact' => $NbContact,
        'NbMsg'=>$NbMsg
    );

    return $recap;
}

/*********************************************************/
function searchbyId($id){
    global $linkPWA_Msg;

    $ask="SELECT  *  FROM user WHERE idUser='".$id."' " ;
    $queryask=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultask=mysqli_query($linkPWA_Msg,$queryask) or die($queryask.' '.mysqli_error($linkPWA_Msg));
    while($varAsk=mysqli_fetch_assoc($resultask))
        {
        extract($varAsk);
        $listeUser[$UserName]= new User(
            $idUser,
            $UserName,
            $ValueConnect
        );
        }

    $recap =array(
        'idUser' => $idUser,
        'UserName' => $UserName,
        'ValueConnect'=>$ValueConnect
    );

    return $recap;
}
/*********************************************************/
function searchbyName($UserName){
    global $linkPWA_Msg;

    $ask="SELECT  *  FROM user WHERE UserName='".$UserName."' " ;
    $queryask=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultask=mysqli_query($linkPWA_Msg,$queryask) or die($queryask.' '.mysqli_error($linkPWA_Msg));
    while($varAsk=mysqli_fetch_assoc($resultask))
    {
        extract($varAsk);
        $listeUser[$UserName]= new User(
            $idUser,
            $UserName,
            $ValueConnect
        );
    }
    foreach ($listeUser as  $UserName => $valueUser)
    {
        $idUser=$valueUser->idUser;
    }
    return $idUser;
}
/*********************************************************/
function InitDb($username){
    global $linkPWA_Msg;
    $message = array();
    $RefreshConvers = array();
    $RefreshUserConvers = array();

    $TrueIdUser= searchbyName($username);
    $ask="SELECT  *  FROM user ORDER BY UserName ASC " ;
    $queryask=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultask=mysqli_query($linkPWA_Msg,$queryask) or die($queryask.' '.mysqli_error($linkPWA_Msg));
    while($varAsk=mysqli_fetch_assoc($resultask))
    {
        extract($varAsk);
        $listeUser[$UserName]= new User(
            $idUser,
            $UserName,
            $ValueConnect
        );
    }
    $UserList='<div >';
    $TempForm='<div ><form>';
    $id_Count=0;
    $listContact='<div ><form>';
    $listMsg='<div ><form>';
    $listConvers='<div ><form>';
    $listConversUser='<div ><form>';
    $CountConversUser = 0;

    foreach ($listeUser as  $UserName => $valueUser)
    {
          $id_Count=$id_Count+1;
          $UserList=$UserList.'<br/><span class=';

          if ($valueUser->ValueConnect==1){
              $UserList=$UserList.'"green"';
          }
          else
          {
              $UserList=$UserList.'"grey"';
          };
          $UserList=$UserList.'>●</span>';
          $UserList=$UserList.$valueUser->UserName.'';

          $TempForm = $TempForm.'<input type="hidden" id="'.$id_Count.'UserName" value="'.htmlentities($valueUser->UserName).'" >';
          $TempForm = $TempForm.'<input type="hidden" id="'.$id_Count.'StatuUserName" value="'.htmlentities($valueUser->ValueConnect).'" >';
    }
    $TempForm = $TempForm.'<input type="hidden"  id="CountUserName" value="'.$id_Count.'" >';
    $TempForm = $TempForm.'</form></div>';
    $UserList = $UserList.'</div>';
    $ConversCount=0;
    $ContactCount = 0;
    $MsgCount = 0;

    $initResultTemp=0;

    $ask="SELECT  count(*) FROM conversuser WHERE idUser = ".$TrueIdUser."  " ;
    $queryasky=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultasky=mysqli_query($linkPWA_Msg,$queryasky)  or die($queryasky.' '.mysqli_error($linkPWA_Msg)) ;
    $resultTemp=mysqli_fetch_array($resultasky);
    $initResultTemp= $resultTemp['count(*)'];

    if ($initResultTemp<>0){
    //****************************************************************************************************//
    $ask="SELECT  *  FROM conversuser WHERE idUser = ".$TrueIdUser."  " ;
    $queryask=$ask ;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
    $resultask=mysqli_query($linkPWA_Msg,$queryask)  or die($queryask.' '.mysqli_error($linkPWA_Msg)) ;

    while($varAsk=mysqli_fetch_assoc($resultask))
    {
        extract($varAsk);
        $listeConversUser[$idConversUser]= new ConversUser(
              $idConversUser,
              $idUser,
              $idConvers
        );
    }

    //********RECUPERATION CONVERS******************************//

         foreach ($listeConversUser as  $idConvers => $valueConversUser) {
             //*****************************************************//
             //*****************************************************//

             $CurrentIdConvers = $valueConversUser->idConvers;
             $ConversVerif = htmlentities($valueConversUser->idConvers);
             $convers = Convers($CurrentIdConvers);
             $NbMsg = $convers['NbMsg'];
             $NbContact = $convers['NbContact'];

             if ($ConversVerif <> 0 & $NbContact > 1)//
             {
                 $ConversCount = $ConversCount + 1;
                 $ConversName = '';


                 $ask = "SELECT  *  FROM conversuser WHERE idConvers = " . $valueConversUser->idConvers . "  ";
                 $queryask = $ask;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
                 $resultask = mysqli_query($linkPWA_Msg, $queryask) or die($queryask . ' ' . mysqli_error($linkPWA_Msg));
                 while ($varAsk = mysqli_fetch_assoc($resultask)) {
                     extract($varAsk);
                     $listeUserConversUseri[$idUser] = new ConversUser(
                         $idConversUser,
                         $idUser,
                         $idConvers
                     );
                 }
                 $ConversName = '';
                 foreach ($listeUserConversUseri as $idUser => $valueUserConversUser) {
                     $TempUseConversId = htmlentities($valueUserConversUser->idConvers);
                     if ($TempUseConversId <> 0) {
                         $CountConversUser = $CountConversUser + 1;
                         $ConversUserName = searchbyId($valueUserConversUser->idUser)['UserName'];

                         if ($ConversUserName <> $username) {
                             $ConversName = $ConversName . $ConversUserName . ' ';
                         }
                         $listConversUser = $listConversUser . '<input type="hidden" id="' . $CountConversUser . 'ConversUserIdConversUser" value="' . htmlentities($valueUserConversUser->idConversUser) . '" >';
                         $listConversUser = $listConversUser . '<input type="hidden" id="' . $CountConversUser . 'ConversUserIdUser" value="' . htmlentities(SearchById($valueUserConversUser->idUser)['UserName']) . '" >';
                         $listConversUser = $listConversUser . '<input type="hidden" id="' . $CountConversUser . 'ConversUserIdConvers" value="' . htmlentities($valueUserConversUser->idConvers) . '" >';

                         $UserConv = array(
                             'Id_UserConv' => $CountConversUser,
                             'IdTemp_UserConvers' => htmlentities($valueUserConversUser->idConversUser),
                             'id_User' => htmlentities(searchbyId($valueUserConversUser->idUser)['UserName']),
                             'id_Convers' => htmlentities($valueUserConversUser->idConvers),
                             'id_UserConvers' => htmlentities($valueUserConversUser->idConversUser));
                         $RefreshUserConvers[] = $UserConv;
                     }
                 }
                 $listConvers = $listConvers . '<input type="hidden" id="' . $ConversCount . 'Convers" value="' . htmlentities($ConversName) . '" >';
                 $listConvers = $listConvers . '<input type="hidden" id="' . $ConversCount . 'ConversId" value="' . htmlentities($valueUserConversUser->idConvers) . '" >';
                 $listConvers = $listConvers . '<input type="hidden" id="' . $ConversCount . 'ConversNbMsg" value="' . htmlentities($NbMsg) . '" >';
                 $listConvers = $listConvers . '<input type="hidden" id="' . $ConversCount . 'ConversNbrContact" value="' . htmlentities($NbContact) . '" >';
                 $Conv = array(
                     'id_Conv' => htmlentities($ConversCount),
                     'Nb_Msg' => htmlentities($valueUserConversUser->NbMsg),
                     'Name' => htmlentities($ConversName),//ICI ATTENTION($valueUserConversUser->Name)
                     'Nb_Contact' => htmlentities($valueUserConversUser->NbContact),
                     'id_Convers' => htmlentities($valueUserConversUser->idConvers),
                     'IdTemp_Convers' => htmlentities($valueUserConversUser->idConvers)
                 );
                 $RefreshConvers[] = $Conv;

                   unset($listeUserConversUseri);
             }


             //********RECUPERATION CONTACT & MSG******************************//

             //********RECUPERATION CONTACT******************************//

             $ask = "SELECT  *  FROM conversuser WHERE idConvers = " . $valueConversUser->idConvers . "  ";
             $queryask = $ask;
             $resultask = mysqli_query($linkPWA_Msg, $queryask) or die($queryask . ' ' . mysqli_error($linkPWA_Msg));
             while ($varAsk = mysqli_fetch_assoc($resultask)) {
                 extract($varAsk);
                 $listeUserConversUser[$idUser] = new ConversUser(
                     $idConversUser,
                     $idUser,
                     $idConvers
                 );
             }
             //*******/
             foreach ($listeUserConversUser as $idUser => $valueUserConversUser) {
                 $LastContact = 0;
                 $idTemp = $valueUserConversUser->idUser;
                 $idConvers = $valueUserConversUser->idConvers;
                 $NbContactByConvers = Convers($idConvers)['NbContact'];
                 if ($LastContact <> $idTemp) {
                     //--------------------------------
                     $ContactCount = $ContactCount + 1;
                     $ContactName = searchbyId($idTemp)['UserName'];
                     $ValueConnectContactName = searchbyId($idTemp)['ValueConnect'];
                     $listContact = $listContact . '<input type="hidden" id="' . $ContactCount . 'Contact" value="' . htmlentities($ContactName) . '" >';
                     $listContact = $listContact . '<input type="hidden" id="' . $ContactCount . 'StatuContact" value="' . htmlentities($ValueConnectContactName) . '" >';
                     $listContact = $listContact . '<input type="hidden" id="' . $ContactCount . 'idConversContact" value="' . htmlentities($idConvers) . '" >';
                     $listContact = $listContact . '<input type="hidden" id="' . $ContactCount . 'ConversNbContact" value="' . htmlentities($NbContactByConvers) . '" >';
                     $LastContact = $idTemp;
                     //--------------------------------

                 }
             }
             //********RECUPERATION MESSAGE******************************//
             $asks = "SELECT  count(*) FROM msg WHERE idConvers = " . $valueConversUser->idConvers . "  ";
             $queryaskys = $asks;//WHERE user.username = '".$username."' AND user.valueConnectUser=1";/*--!>*/
             $resultaskys = mysqli_query($linkPWA_Msg, $queryaskys) or die($queryaskys . ' ' . mysqli_error($linkPWA_Msg));
             $resultTemps = mysqli_fetch_array($resultaskys);
             $initResultTempsy = $resultTemps['count(*)'];

             if ($initResultTempsy <> 0) {
                 $asky = "SELECT  *  FROM msg WHERE idConvers = " . $valueConversUser->idConvers . "  ";
                 $queryasky = $asky;
                 $resultasky = mysqli_query($linkPWA_Msg, $queryasky) or die($queryasky . ' ' . mysqli_error($linkPWA_Msg));
                 while ($varAsky = mysqli_fetch_assoc($resultasky)) {
                     extract($varAsky);
                     $listedMsg[$idMsg] = new Msg(
                         $idMsg,
                         $idUser,
                         $idConvers,
                         $Msg,
                         $Date,
                         $IdTemp_Msg
                     );
                 }
                 //*******/
                 foreach ($listedMsg as $idMsg => $valueMsg) {
                     $idUserMsg = $valueMsg->idUser;
                     $idConversMsg = $valueMsg->idConvers;
                     //--------------------------------
                     $MsgCount = $MsgCount + 1;
                     $MsgContactName = searchbyId($idUserMsg)['UserName'];
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'MsgContact" value="' . htmlentities($MsgContactName) . '" >';
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'MsgIdConvers" value="' . htmlentities($idConversMsg) . '" >';
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'MsgTxt" value="' . htmlentities($valueMsg->Msg) . '" >';
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'MsgDate" value="' . htmlentities($valueMsg->Date) . '" >';
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'MsgIdMsg" value="' . htmlentities($valueMsg->idMsg) . '" >';
                     $listMsg = $listMsg . '<input type="hidden" id="' . $MsgCount . 'IdTemp_Msg" value="' . htmlentities($valueMsg->IdTemp_Msg) . '" >';
                     //--------------------------------
                     $msg = array(
                         'id_message' => htmlentities($MsgCount),
                         'MsgContact' => htmlentities($MsgContactName),
                         'MsgIdConvers' => htmlentities($idConversMsg),
                         'MsgTxt' => htmlentities($valueMsg->Msg),
                         'MsgDate' => htmlentities($valueMsg->Date),
                         'MsgIdMsg' => htmlentities($valueMsg->idMsg),
                         'MsgIdTempMsg' => htmlentities($valueMsg->IdTemp_Msg));
                     $message[] = $msg;
                 }
                 $listMsg = $listMsg;
                 //*****************************************************//
                 //*****************************************************//
             }
         }
}
    $listConvers = $listConvers . '<input type="hidden" id="CountConvers" value="' . htmlentities($ConversCount) . '" >';
    $listConvers = $listConvers . '</form></div >';

    $listConversUser = $listConversUser . '<input type="hidden" id="CountUserConvers" value="' . htmlentities($CountConversUser) . '" >';
    $listConversUser = $listConversUser . '</form></div >';

    $listMsg = $listMsg . '<input type="hidden" id="CountMsg" value="' . htmlentities($MsgCount) . '" >';
    $listMsg = $listMsg . '</form></div >';

    $listContact = $listContact . '<input type="hidden" id="CountContact" value="' . htmlentities($ContactCount) . '" >';
    $listContact = $listContact . '</form></div >';

    $recapUser=array(
        //---Init--------//
        'PhpList'=>$UserList,
        'JavaList'=>$TempForm,
        'MsgList'=>$listMsg,
        'ContactList'=> $listContact,
        'ConversList'=> $listConvers,
        'UserConversList'=> $listConversUser,
        //---Refresh-----//
        'Message'=>$message,
        'RefreshConvers'=>$RefreshConvers,
        'RefreshUserConvers'=>$RefreshUserConvers,
    );
    return $recapUser;
}
?>