<?php

include('session.php');

if($_SESSION['username'] !== ""){
    $username = securite_bdd($_SESSION['username']);
    $query="UPDATE user SET ValueConnect='0' WHERE username='".$username."'";
    $result=mysqli_query($linkPWA_Msg,$query) or die($query.' '.mysqli_error($linkPWA_Msg ));

}

header("Location: ../index.php");
?>