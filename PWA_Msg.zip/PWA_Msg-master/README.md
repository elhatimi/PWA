https://jeanritter.alwaysdata.net/SynChat/index.php <br/>
Projet de Groupe Master SYNVA2: Progressive Web Application | Messagerie (PWA_Msg)
       <ul>
<li>Hajar El HATIMI | elhatimi </li>
<li>Céline POLOCE | cpoloce </li>
<li>Jean RITTER | Tchangallah </li>
<li>Clara STEIN | GinevraH </li>
      </ul>

Fonctionnalités implantées:
       <ul>
<li>notifications</li>
<li>creation d'un compte utilisateur</li>
<li>engagé une nouvelle conversation </li>
<li>envoi et reception de message </li>
<li>application fonctionnant offline avec stockage des informations dans un indexeddb </li>
<li>dynamique assuré entre PHP et JavaScript, mode online et offline assuré avec AJAX & JQuery & ServiceWorker </li>
        </ul>	      </ul>


