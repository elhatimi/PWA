

self.addEventListener('install', event =>{

    caches.open('SynChat').then(
        cache =>{
           return cache.addAll([
                '/',
                '/sw.js',

                '/index.php',
                '/manifest.webmanifest',

                '/css/styles.css',

                '/php/connect.php',
                '/php/connectDB.inc',
                '/php/construct.php',
                '/php/disconnect.php',
                '/php/edit.php',
                '/php/editConvers.php',
                '/php/inscriptions.php',
                '/php/NewConvers.php',
                '/php/refresh.php',
                '/php/session.php',

                '/js/core/bootstrap.bundle.min.js',
                '/js/core/jquery.easing.min.js',
                '/js/core/jquery.min.js',
                '/js/core/jquery-3.2.1.min.js',
                '/js/core/processing.min.js',
                '/js/core/scripts.js',

                '/js/welcome.js',
                '/js/function.js',
                '/js/connect.js',
                '/js/linker.js',
                '/js/show.js',
                '/js/init.js',

                '/assets/img/about.svg',
                '/assets/img/connected.svg',
                '/assets/img/connexion.svg',
                '/assets/img/msg.svg',
                '/assets/img/phone.svg',
                '/assets/img/welcome.svg',
                '/assets/img/welcome.png',
                '/assets/img/online.svg',
                '/assets/img/yassou.svg',
                '/assets/img/yassou.png',

                '/assets/img/sketch.pde',
                '/assets/img/favicon.png',
                '/assets/img/icons/icon-512x512.png',
                '/assets/img/icons/icon-384x384.png',
                '/assets/img/icons/icon-192x192.png',
                '/assets/img/icons/icon-180x180.png',
                '/assets/img/icons/icon-152x152.png',
                '/assets/img/icons/icon-144x144.png',
                '/assets/img/icons/icon-128x128.png',
                '/assets/img/icons/icon-96x96.png',
                '/assets/img/icons/icon-76x76.png',
                '/assets/img/icons/icon-72x72.png',
                '/assets/img/icons/icon-60x60.png',
                '/assets/img/icons/icon-57x57.png',
                '/assets/img/icons/icon-32x32.png',
                '/assets/img/icons/icon-16x16.png',

                '/assets/fonts/Uni-Bold.ttf',
                '/assets/fonts/Uni-BoldItalic.ttf',
                '/assets/fonts/Uni-Regular.ttf',
                '/assets/fonts/Uni-Italic.ttf'

            ]);
        }
    )
});
self.addEventListener('activate', function(event) {

});


self.addEventListener('fetch', event =>{

    event.respondWith(
        caches.match(event.request).then(response=>{

            if(event.request.method == "POST")
            {
                return fetch(event.request);
            }
            if(response){
                return response;
            }
            else{
                return fetch(event.request).then(
                    newResponse=>{
                        caches.open('SynChat').then(
                            cache=>cache.put(event.request, newResponse)
                        );
                        return newResponse.clone();
                    }
                );
            }
        })
    );
});

