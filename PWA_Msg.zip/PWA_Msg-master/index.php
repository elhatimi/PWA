<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <meta name="description" content="" />
        <meta name="author" content="" />

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes" />
        <!--<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=0.61, maximum-scale=1.61, minimum-scale=0.1, shrink-to-fit=no"/>-->
        <meta name="theme-color" content="#3f3d56"/>
        <!--//Chrome, Firefox OS and Opera-->
        <meta name=theme-color content="#3f3d56" />
        <!--// Windows Phone -->
        <meta name=msapplication-navbutton-color content="#3f3d56" />
        <!--// iOS Safari-->
        <meta name=apple-mobile-web-app-status-bar-style content="#3f3d56" />
        <!-- Favicon-->
       <link rel="shortcut icon" type="image/png" href="assets/img/favicon.png"/>
        <!-- Font Awesome icons (free version)-->
        <script src="js/core/all.js" crossorigin="anonymous"></script>


        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <!-- Canonical Adress--> 
        <link rel="canonical" href="https://jeanritter.alwaysdata.net/SynChat/index.php" /> <!--preciser adresse-->
        <!-- WEBMANIFEST -->
        
        <link rel="manifest" href="manifest.webmanifest"/>
        <link rel="apple-touch-icon" href="images/icons/icon-192x192.png" />
        <!-- Service Worker-->
        <script>
            if ('serviceWorker' in navigator){
                navigator.serviceWorker.register('sw.js').then(reg => {
                    reg.update();
                })}
        </script>
        <?php
        include('php/session.php');

             $title='SynChat';
        if($ValidityUserName==1)
        {
            $title = $username.' | SynChat';
        }
        echo "<title>",$title,"</title>";
        ?>
    </head>

    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top">
                <?php
                 if($ValidityUserName<>1)
                    {
                    echo "SynChat</a>";
                    }
                else{
                    echo $username,"</a>";
                    echo "<form type=\"hidden\" >";
                    echo "<input ";
                    echo "type=\"hidden\"";
                    echo "  id=\"BDName\" value=\"".htmlentities($username)."\" >";
                    echo "</form>";
                    echo InitDb($username)['JavaList'];
                    echo InitDb($username)['ContactList'];
                    echo InitDb($username)['MsgList'];
                    echo InitDb($username)['ConversList'];
                    echo InitDb($username)['UserConversList'];
                    };
                ?>

                <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <?php
                        if($ValidityUserName<>1)
                             {
                            echo '<li class="nav-item mx-0 mx-lg-1" data-toggle="modal" data-target="#portfolioModal1">              
                                       <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#"> Connexion</a>
                                     </li>';
                            echo '<li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#inscription">Inscription</a></li>';
                             }
                        ?>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#about">
                               <?php if ($ValidityUserName <> 1) {
                                echo "A propos";
                                }
                                else
                                {
                                echo "SynCha";
                                };
                                ?>
                               </a></li>
                        <!--
                          <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact">Contact</a></li>
                        -->
                        <?php
                        if($ValidityUserName==1)
                        {
                            echo ' <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="php/disconnect.php"">Deconnexion</a></li>';
                        }
                        ?>
                    </ul>
                    <div>
                        <?php
                        if($ValidityUserName==1)
                        {
                            echo connexion();
                        }
                        ?>
                    </div>
                </div>

            </div>
        </nav>
        <!-- Masthead-->

        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->

                <!-- Masthead Heading-->

                <?php
              //  <img class="masthead-avatar mb-5" src="assets/img/avataaars.svg" alt="" />
                if($ValidityUserName<>1)
                    {
                    echo '<div class="text-center mt-4"><p><img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/connected.svg" alt="" /></p></div>';
                    echo "<h1 class=\"masthead-heading text-uppercase mb-0\">SynChat</h1>";
                    }
                else{
                    echo ' <canvas  style =" background:transparent;"width="250px" height="250px" data-processing-sources="assets/img/sketch.pde"></canvas>';
                    echo "<h1 class=\"masthead-heading text-uppercase mb-0\">",$username,"</h1>";
                    };
                ?>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-light mb-0"><em>Gardez le lien!</em></p><br/>

            </div>
            <!-- Portfolio Grid Items-->
            <div class="row justify-content-center">
                <!-- Portfolio Item 1-->
                <div class="col-md-6 col-lg-4 mb-5">
                    <div class="portfolio-item mx-auto" data-toggle="modal" data-target="#portfolioModal1">
                        <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                            <div class="portfolio-item-caption-content text-center text-white">
                             <!--   <i class="fas fa-plus fa-3x"></i> -->
                            </div>
                        </div>
                        <?php
                        if($ValidityUserName<>1)
                        {
                            echo '
                        <a class="btn btn-primary btn-xl" href="#">
                              CONNEXION
                        </a>
                        ';
                        }
                        ?>

                        <!-- <img class="img-fluid" src="assets/img/portfolio/cabin.png" alt="" /> -->
                    </div>
                </div>
            </div>
        </header>
        <!-- Portfolio Section-->
        <?php
        if($ValidityUserName<>1) {
            echo "<script  src=\"js/connect.js\" \"defer\">";
            echo "</script>";

        echo '<section class="page-section portfolio" id="inscription">';
        echo '<div class="container">';
                /*<!-- Portfolio Section Heading-->*/
            echo '<div class="text-center mt-4"><p><img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/phone.svg" alt="" /></p></div>';

            echo '<h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Inscription</h2>';
                /*<!--INSCRIPTION-->*/
            echo '<div class="divider-custom">';
            echo '<div class="divider-custom-line"></div>';
            echo '<div class="divider-custom-icon"><i class="fas fa-star"></i></div>';
            echo '<div class="divider-custom-line"></div>';
            echo '</div>';

                $Inscription = "<div id=\"id_main\" class=\"text-center mt-4\"></div>";

                   echo $Inscription;
                 }
               else
                 {
                     echo '<div class="text-center "><img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/connected.svg"  alt="" /></div>';
                     echo '<h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">SynChat</h2>';
                     /*<!--INSCRIPTION-->*/
                     echo '<div class="divider-custom">';
                     echo '<div class="divider-custom-line"></div>';
                     echo '<div class="divider-custom-icon"><i class="fas fa-star"></i></div>';
                     echo '<div class="divider-custom-line"></div>';
                     echo '</div>';
                     echo '<div id="divMsg">';
                     echo     '<div id="id_ListConvers" >';
                     echo        InitDb($username)['PhpList'];
                     echo     '</div>';
                     echo          '<div id="conversation">';
                     echo          '<div id="UserConv"><h3>Bienvennue</h3></div>';
                     echo               '<div id="Convers"><p><img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/online.svg" alt="" /></p></div>';
                     echo               '<div id="discussEnter"></div>';
                     echo          '</div>';
                     echo     '<div id="id_ListUser">';
                     echo '</div>';
                 };

           echo ' </div>
            </div>
        </section>'; ?>
        <!-- About Section-->

        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <div class="text-center mt-4"><p><img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/about.svg" alt="" /></p></div>
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">
                <?php
                if ($ValidityUserName <> 1)
                {
                    echo "A propos";
                }
                else
                {
                    echo "SynCha";
                };
                  ?>
                </h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>

                <!-- About Section Content-->

                   <div class="row" >
                       <div class="col-lg-4 ml-auto" ><p class="lead" ><b>SynChat</b> est une messagerie instantanée avec laquelle vous pourrez réunir votre environnement professionnel et personnel. Un pseudo, un mot de passe et à toi de garder le liens et ton ticket d'entrée vers le monde</p ></div >
                       <div class="col-lg-4 mr-auto" ><p class="lead" >Ce site est une <em>Progressive Web Application</em> (PWA) disponible en téléchargement sur tout vos supports. Cette messagerie est projet universitaire réalisé dans le cadre du Master SYNVA de l'Université de <b>Strasbourg</b></p></p ></div >
                    </div >


            </div>
        </section>

        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Location</h4>
                        <p class="lead mb-0">
                            https://www.alwaysdata.com/fr/
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">GitHub</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="https://github.com/Tchangallah/PWA_Msg"><i class="fab fa-fw fa-github"></i></a>
                       <!-- <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-dribbble"></i></a>-->

                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">Thème Freelancer</h4>
                        <p class="lead mb-0">
                            Freelance est libre d'usage: MIT licensed Bootstrap theme created by
                            <a href="http://startbootstrap.com">Start Bootstrap</a>, et modifié dans le cadre du projet SynChat
                            .
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Hajar El HATIMI | Céline POLOCE | Jean RITTER | Clara STEIN </small></div>
        </div>
        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
        <div class="scroll-to-top d-lg-none position-fixed">
            <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i class="fa fa-chevron-up"></i></a>
        </div>
        <!-- Portfolio Modals-->
        <!-- Portfolio Modal 1-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-labelledby="portfolioModal1Label" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class="fas fa-times"></i></span>
                    </button>
                    <div class="modal-body text-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Image-->
                                    <div class="text-center mt-4">
                                        <p>
                                            <img class="masthead-avatar " style="width:250px;height:250px;margin:auto;" src="assets/img/connexion.svg" alt="" />
                                        </p>
                                    </div>
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0" id="portfolioModal1Label">Connexion</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>

                                    <?php
                                    echo connexion();
                                    ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JS-->
        <script src="js/core/jquery.min.js" ></script>
        <script src="js/core/bootstrap.bundle.min.js" ></script>
        <!-- Third party plugin JS-->
        <script src="js/core/jquery.easing.min.js" ></script>
        <!-- Core theme JS-->
        <script src="js/core/scripts.js"></script>
    </body>
    <?php
    if($ValidityUserName==1)
    {
        echo "<script  src=\"js/core/jquery-3.2.1.min.js\"></script>";
        echo "<script  src=\"js/function.js\" type=\"text/javascript\" \"defer\" ></script>";
        echo "<script  src=\"js/linker.js\" type=\"text/javascript\" \"defer\" ></script>";
        echo "<script  src=\"js/show.js\" type=\"text/javascript\" \"defer\" ></script>";
        echo "<script  src=\"js/init.js\" type=\"text/javascript\" \"defer\" ></script>";
        echo "<script src=\"js/core/processing.min.js\"></script>";
    }else
    {
        ///--NOTIFICATION----------------------------------
        echo "<script  src=\"js/welcome.js\" type=\"text/javascript\" \"defer\" ></script>";
        //--------------------------------------------------
    };
    ?>
</html>
