localStorage.setItem("StatutConnexion", "off");
var statutConnect = localStorage.getItem("StatutConnexion");
//---------------------------------------------------------
setInterval(() => {
//---------------------------------------------------------
    if (navigator.onLine) {
        statutConnect = localStorage.getItem("StatutConnexion");

       if (statutConnect =='off')
         {
         let content=document.getElementById("id_main").innerHTML=  '<form action=php/inscription.php method=POST>'
                   + '<fieldset>'
                   + '<legend class="hide">Inscription</legend>'

                   + '<div class="control-group">'
                   +    '<div class="form-group floating-label-form-group controls mb-0 pb-2">'
                   +    '<label>Nom d\'utilisateur</label>'
                   +    '<input type=\"text\" placeholder=\"Nom d\'utilisateur\" name=\"username\" required pattern=\"[a-zA-Z0-9 ]*\">'
                   +    '<p class="help-block text-danger"></p>'
                   +    '</div>'
                   + '</div>'

                   + '<div class="control-group">'
                   +    '<div class="form-group floating-label-form-group controls mb-0 pb-2">'
                   +    '<label>Mot de passe</label>'
                   +    '<input type=\"password\" placeholder=\"Mot de passe\" name=\"password\" required pattern=\"[a-zA-Z0-9 ]*\">'
                   +    '<p class="help-block text-danger"></p>'
                   +    '</div>'
                   + '</div>'

                   + '<br/><div class=\"form-group\">'
                      + '<button class=\"btn btn-primary btn-xl\" type=\"submit\" id=\"submit\" >'
                      + 'S\'INSCRIRE'
                      + '</button>'
                   + '</div>'

                   +  '</fieldset>'
          + '</form>'


      ;

      localStorage.setItem("StatutConnexion", "on");
      }

 }

 else
 {
  let content=document.getElementById("id_main").innerHTML='Vous n\'etes plus en ligne!';
  localStorage.setItem("StatutConnexion", "off");
 }


 ///--------------------------------------------------------  */
}, 500);
///--------------------------------------------------------
