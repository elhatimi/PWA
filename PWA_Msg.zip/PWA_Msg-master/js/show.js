//***********************************************************************************//
//var timeout = 1000;
var showmsg = function() {

    $.ajax({
        method: 'POST',
        url: 'php/refresh.php'
    })
        .done(function(msg){
            var tab = jQuery.parseJSON(msg);
            tab.forEach(function(message){
                if(!$('#message-' + message.id_message).length)
                {
                    /*                       //DEBUG
                                        localStorage.setItem("lid_message", message.id_message);
                                        localStorage.setItem("lIdTemp_Msg", message.MsgContact);
                                        localStorage.setItem("lContact_Msg", message.Contact_Msg);
                                        localStorage.setItem("lid_Convers", message.MsgIdConvers);
                                        localStorage.setItem("lIdTemp_Msg", message.MsgTxt);
                                        localStorage.setItem("lContact_Msg", message.MsgDate);
                                        localStorage.setItem("lId_Msg", message.MsgIdMsg);
                    */
                    var tempIdMsgReciep = message.MsgIdTempMsg;
                    if(tempIdMsgReciep===0 || tempIdMsgReciep==="0" ){}
                    else {
                        var conversObji =
                            {
                                //-------------------------------*/
                                IdTemp_Msg: message.MsgIdTempMsg+"",
                                Contact_Msg: message.MsgContact + "",
                                id_Convers: message.MsgIdConvers + "",
                                Msg_Msg: message.MsgTxt + "",
                                Date_Msg: message.MsgDate + "",
                                Id_Msg: message.MsgIdMsg +"",
                                Statut_Msg: 'Init'
                                //-------------------------------*/
                            };
                        Add(conversObji, 'Msg');
                    }
                }
            });
        });
    //-------------------------------------------------------------//

};
//showmsg();
//--------------------------------------------------------------------------------

var showConvers = function() {
    $.ajax({
        method: 'POST',
        url: 'php/refreshConv.php'
    })
        .done(function(Conv){
            var tabConv = jQuery.parseJSON(Conv);
            tabConv.forEach(function(RefreshConvers){
                if(!$('#RefreshConvers-' + RefreshConvers.id_Conv).length)
                {

                        var tempIdConvers =RefreshConvers.id_Convers+"";
                        if(tempIdConvers===0 ||tempIdConvers==="0" ){}
                        else{
                           var conversObjyc =
                            {
                            //-------------------------------
                            IdTemp_Convers :  RefreshConvers.IdTemp_Convers,
                            Name_Convers: RefreshConvers.Name+"",
                            Nb_Msg : RefreshConvers.Nb_Msg+"",
                            Nb_Contact: RefreshConvers.Nb_Contact+"",
                            id_Convers: RefreshConvers.id_Convers+"",
                            StatuConvers: "Init",
                            //-------------------------------
                            };
                            //DEBUG
                            /*
                            localStorage.setItem("RefreshIdTempConvers",RefreshConvers.IdTemp_Convers+"");
                            localStorage.setItem("RefreshNbMsg", RefreshConvers.Nb_Msg+"");
                            localStorage.setItem("RefreshNbContact",RefreshConvers.Nb_Contact+"");
                            localStorage.setItem("RefreshNbIdConvers",RefreshConvers.id_Convers+"");
*/
                    Add(conversObjyc ,'Convers');
                        }
                }
            });
        });
    // setTimeout(showConvers, timeout);
};
//showConvers();
//--------------------------------------------------------------------------------

var showUserConvers = function() {
    $.ajax({
        method: 'POST',
        url: 'php/refreshUserConv.php'
    })
        .done(function(UserConv){
            var tabUserConv = jQuery.parseJSON(UserConv);
            tabUserConv.forEach(function(RefreshUserConvers){
                if(!$('#RefreshUserConvers-' + RefreshUserConvers.Id_UserConv).length)
                {
                    var conversObjycy =
                        {
                            //-------------------------------
                            Id_UserConv : RefreshUserConvers.Id_UserConv+"",
                            IdTemp_UserConvers : RefreshUserConvers.IdTemp_UserConvers+"",
                            id_User: RefreshUserConvers.id_User+"",
                            id_Convers: RefreshUserConvers.id_Convers+"",
                            id_UserConvers: RefreshUserConvers.id_UserConvers+"",
                            //-------------------------------
                        };
                    //DEBUG
                    /*
                    localStorage.setItem("RefreshConvId_UserConv", RefreshUserConvers.Id_UserConv+"");

                    localStorage.setItem("RefreshConvIdTempUserConvers", RefreshUserConvers.IdTemp_UserConvers+"");
                    localStorage.setItem("RefreshConvid_User", RefreshUserConvers.id_User+"");
                    localStorage.setItem("RefreshConvid_Convers",RefreshUserConvers.id_Convers+"");
                    localStorage.setItem("RefreshConvidUserConvers",RefreshUserConvers.id_UserConvers+"");
                     */
                    Add(conversObjycy ,'UserConvers');
                }
            });
        });
    // setTimeout(showUserConvers, timeout);
};
//showUserConvers(); /**/