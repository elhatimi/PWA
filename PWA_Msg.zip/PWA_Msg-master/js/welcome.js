///--NOTIFICATION----------------------------------
if (window.Notification && window.Notification !== 'denied') {
    Notification.requestPermission(perm => {
        if (perm === 'granted') {
            var notification = new Notification('Bienvennue', {
                icon: 'assets/img/icons/icon-60x60.png',
                body:' Gardez le lien avec cette messagerie',
                image: 'assets/img/yassou.png'
            });

        } else {
        }
    })
}
//--------------------------------------------------