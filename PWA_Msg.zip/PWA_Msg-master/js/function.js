var dbMsgUser;
var prefixeBD = 'SynChat';

var Doc_Get_El_id_BDName=document.getElementById('BDName');
var TrueUserName = Doc_Get_El_id_BDName.value;

var NameDB= prefixeBD + TrueUserName;
var MsgUser = indexedDB.open(NameDB);
///--NOTIFICATION----------------------------------
if (window.Notification && window.Notification !== 'denied') {
    Notification.requestPermission(perm => {
        if (perm === 'granted') {
            var notification = new Notification('Bienvennue', {
                icon: 'assets/img/icons/icon-60x60.png',
                body:' Gardez le lien '+TrueUserName,
                image: 'assets/img/welcome.png'
            });

        } else {
        }
    })
}
//--------------------------------------------------
MsgUser.onupgradeneeded = function(event)
{
    //----------------------------------------------------------------------
    // EIDITION OU ET CREATION DE LA BASE DE DONNEE
    //----------------------------------------------------------------------
    var dbMsgUser = event.target.result;
    //-------------------------
    var objectStore = dbMsgUser.createObjectStore(NameDB+'Msg',{keyPath: "IdTemp_Msg"});
    var id_Msg = objectStore.createIndex("Contact_Msg","Contact_Msg");
    var Convers_Msg = objectStore.createIndex("id_Convers","id_Convers");
    var Msg_Msg = objectStore.createIndex("Msg_Msg","Msg_Msg");
    var Date_Msg = objectStore.createIndex("Date_Msg","Date_Msg");
    var lId_Msg = objectStore.createIndex("Id_Msg","Id_Msg");
    var Statut_Msg = objectStore.createIndex("Statut_Msg","Statut_Msg");
    //-------------------------
    var objectStoreu = dbMsgUser.createObjectStore(NameDB+'Convers',{keyPath: "IdTemp_Convers"});
    var Name_Convers = objectStoreu.createIndex("Name_Convers","Name_Convers");
    var id_Convers = objectStoreu.createIndex("id_Convers","id_Convers");
    var Nb_Msg = objectStoreu.createIndex("Nb_Msg","Nb_Msg");
    var Nb_Contact = objectStoreu.createIndex("Nb_Contact","Nb_Contact");
    var StatutConvers = objectStoreu.createIndex("StatuConvers","StatuConvers");
    //-------------------------
    var objectStores = dbMsgUser.createObjectStore(NameDB+'UserConvers',{keyPath: "IdTemp_UserConvers"});
    var id_ConversU = objectStores.createIndex("id_Convers","id_Convers");
    var id_UserConvers = objectStores.createIndex("id_UserConvers","id_UserConvers");
    var id_UserU = objectStores.createIndex("id_User","id_User");
    var StatutUserConvers = objectStores.createIndex("StatuUserConvers","StatuUserConvers");
    //-------------------------
    var objectStory = dbMsgUser.createObjectStore(NameDB+'Contact',{keyPath: "IdTemp_User"});
    var UserName = objectStory.createIndex("UserName","UserName");
    var StatuUserName = objectStory.createIndex("StatuUserName","StatuUserName");
    var Conver = objectStory.createIndex("ConversUserName","ConversUserName");
    var NbContact = objectStory.createIndex("NbContact","NbContact");
    //-------------------------
    var objectStorys = dbMsgUser.createObjectStore(NameDB+'UserName',{keyPath: "IdTemp_User"});
    var UserNames = objectStorys.createIndex("UserName","UserName");
    var StatuUserNames = objectStorys.createIndex("StatuUserName","StatuUserName");
    var ContactStatu = objectStorys.createIndex("ContactStatu","ContactStatu");
    //----------------------------------------------------------------------
}
var dbListUser;
//***************************************************************************************************************************************
function recupMsg(i){
    //-----------------------------------------------------------
    let idMsgContact = i + 'MsgContact';
    let Doc_Get_El_MsgContact = document.getElementById(idMsgContact);
    let Contact_Msg = Doc_Get_El_MsgContact.value;
    //  localStorage.setItem("Contact_Msg", Contact_Msg);
    //-----------------------------------------------------------
    let idConversId = i + 'MsgIdConvers';
    let Doc_Get_El_IdConversId = document.getElementById(idConversId);
    let id_Convers = Doc_Get_El_IdConversId.value;
    //  localStorage.setItem("id_Convers", id_Convers);
    //-----------------------------------------------------------
    let idMsgTxt = i + 'MsgTxt';
    let Doc_Get_El_MsgTxt = document.getElementById(idMsgTxt );
    let Msg_Msg = Doc_Get_El_MsgTxt.value;
    //  localStorage.setItem("Msg_Msg", Msg_Msg );
    //-----------------------------------------------------------
    let idDate = i + 'MsgDate';
    let Doc_Get_El_Date = document.getElementById(idDate);
    let Date_Msg  = Doc_Get_El_Date.value;
    //  localStorage.setItem("Date_Msg", Date_Msg );
    //-----------------------------------------------------------
    let idMsgId = i + 'MsgIdMsg';
    let Doc_Get_El_MsgId = document.getElementById(idMsgId);
    let Id_Msg  = Doc_Get_El_MsgId.value;
    //  localStorage.setItem("Id_Msg", Id_Msg );
    //-----------------------------------------------------------
    let idIdTemp_Msg = i + 'IdTemp_Msg';
    let Doc_Get_El_IdTemp_Msg = document.getElementById(idIdTemp_Msg);
    let IdTemp_Msg  = Doc_Get_El_IdTemp_Msg.value;
    //  localStorage.setItem("Id_Msg", Id_Msg );
    //-----------------------------------------------------------

    var conversObji =
        {
            //-------------------------------*/
            IdTemp_Msg : IdTemp_Msg,
            Contact_Msg : Contact_Msg,
            id_Convers : id_Convers,
            Msg_Msg: Msg_Msg,
            Date_Msg: Date_Msg,
            Id_Msg: Id_Msg,
            Statut_Msg :'Init'
            //-------------------------------*/
        };
    return conversObji;
}
function recupConvers(i){
    //-----------------------------------------------------------
    let idConvers = i + 'Convers';
    let Doc_Get_El_IdConvers = document.getElementById(idConvers);
    let Convers = Doc_Get_El_IdConvers.value;
    //localStorage.setItem("Convers", Convers);
    //-----------------------------------------------------------
    let idConversId = i + 'ConversId';
    let Doc_Get_El_IdConversId = document.getElementById(idConversId);
    let ConversId = Doc_Get_El_IdConversId.value;
    //localStorage.setItem("ConversId", ConversId);
    //-----------------------------------------------------------
    let idConversNbMsg = i + 'ConversNbMsg';
    let Doc_Get_El_IdConversNbMsg = document.getElementById(idConversNbMsg );
    let ConversNbMsg  = Doc_Get_El_IdConversNbMsg.value;
    //localStorage.setItem("ConversNbMsg", ConversNbMsg );
    //-----------------------------------------------------------
    let idConversNbContact = i + 'ConversNbrContact';
    let Doc_Get_El_IdConversNbContact = document.getElementById(idConversNbContact);
    let ConversNbContact  = Doc_Get_El_IdConversNbContact.value;
    //localStorage.setItem("ConversNbrContact", ConversNbContact );
    //-----------------------------------------------------------
    if(ConversNbContact==0 || ConversId ===0 || Convers ===0 ){}
    else{
        var conversObji =
            {
                //-------------------------------*/
                IdTemp_Convers: ConversId,
                Name_Convers: Convers,
                Nb_Contact: ConversNbContact,
                id_Convers: ConversId,
                Nb_Msg: ConversNbMsg,
                StatuConvers: "Init"
                //-------------------------------*/
            };
        return conversObji;
    }
}
function recupConversUser(i){
    //localStorage.setItem("youpla", 'youpla');
    //-----------------------------------------------------------
    let idConversUserIdConvers = i + 'ConversUserIdConvers';
    let Doc_Get_El_IdConversUserIdConvers = document.getElementById(idConversUserIdConvers);
    let ConversUserIdConvers = Doc_Get_El_IdConversUserIdConvers.value;
    localStorage.setItem("ConversUserIdConvers", ConversUserIdConvers);
    //-----------------------------------------------------------
    let idConversUserIdConversUser = i + 'ConversUserIdConversUser';
    let Doc_Get_El_IdConversUserIdConversUser = document.getElementById(idConversUserIdConversUser);
    let ConversUserIdConversUser = Doc_Get_El_IdConversUserIdConversUser.value;
    localStorage.setItem("ConversUserIdConversUser", ConversUserIdConversUser);
    //-----------------------------------------------------------
    let idConversUserIdUser = i + 'ConversUserIdUser';
    let Doc_Get_El_IdConversUserIdUser = document.getElementById(idConversUserIdUser);
    let ConversUserIdUser = Doc_Get_El_IdConversUserIdUser.value;
    localStorage.setItem("TestConversUserIdUser", ConversUserIdUser);
    //-----------------------------------------------------------
    if (typeof ConversUserIdUser== 'number'){}
    else{
    var conversUserObj =
        {
            //-------------------------------*/
            IdTemp_UserConvers: ConversUserIdConversUser,
            id_Convers : ConversUserIdConvers,
            id_UserConvers : ConversUserIdConversUser,
            id_User : ConversUserIdUser + "",
            StatuUserConvers : "Init"
            //-------------------------------*/
        };
    return conversUserObj;
    }
}
function recupUser(i,Nam) {
    if (Nam === 'TrueContact')
    {
        var Name = 'Contact';
    }
    else
    {
        var Name = Nam;
    }
    //-----------------------------------------------------------
    let idUserName = i + Name;
    let Doc_Get_El_IdUser = document.getElementById(idUserName);
    let UserName = Doc_Get_El_IdUser.value;
    //  localStorage.setItem("UserName", UserName);
    //-----------------------------------------------------------
    let idStatuUserName = i + 'Statu' + Name;
    let Doc_Get_El_idStatuUserName= document.getElementById(idStatuUserName);
    let StatuUserName = Doc_Get_El_idStatuUserName.value;
    //  localStorage.setItem("StatuUserName", StatuUserName);
    if (Nam === 'Contact')
    {
        let idConversUserName = i + 'idConvers' + Name;
        let Doc_Get_El_idConversUserName= document.getElementById(idConversUserName);
        var ConversUserName = Doc_Get_El_idConversUserName.value;
        //     localStorage.setItem("ConversUserName", ConversUserName);
        let idConversNb = i + 'ConversNb' + Name;
        let Doc_Get_El_idConversNb = document.getElementById(idConversNb);
        var ConversNb = Doc_Get_El_idConversNb.value;
        //     localStorage.setItem("NbContact", ConversNb);
        var userObj =
            {
                //-------------------------------*/
                IdTemp_User : UserName+ConversUserName,
                UserName : UserName,
                StatuUserName : StatuUserName,
                ConversUserName : ConversUserName,
                NbContact : ConversNb
                //-------------------------------*/
            };
    }
    else
    {
        if (Nam === 'TrueContact')
        {
            var userObj =
                {
                    //-------------------------------*/
                    IdTemp_User: UserName,
                    UserName: UserName,
                    StatuUserName: StatuUserName,
                    ContactStatu: '1'
                    //-------------------------------*/
                };
        }
        else {
            var userObj =
                {
                    //-------------------------------*/
                    IdTemp_User: UserName,
                    UserName: UserName,
                    StatuUserName: StatuUserName,
                    ContactStatu: '0'
                    //-------------------------------*/
                };
        }
    }
    return userObj;
// document.getElementById(id_IdTemp)).innerHTML='';
}

function Add(obj, Name){
    var List =indexedDB.open(NameDB);
    if (Name==='TrueContact')
    {
        var Name ='UserName';
    }
    List.onsuccess = ev =>
    {
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        var NameDBName=NameDB+Name;
        var dbList = ev.target.result;
        const transaction = dbList.transaction(NameDBName, 'readwrite');
        const store = transaction.objectStore(NameDBName);
        const data = [obj];
        data.forEach (el => store.put(el));
        //-----------------------------------------------
        //-----------------------------------------------
        transaction.oncomplete = ev =>
        {
            const store = dbList.transaction(NameDBName,'readwrite').objectStore(NameDBName);
            const query = store.openCursor();
        }
        //-----------------------------------------------
        //-----------------------------------------------
        //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    }
}
function InitListUser(Nam){

    if (Nam === 'TrueContact')
    {
        var Name= 'UserName';
        var CountName = 'Contact';
    }
    else
    {
        var Name= Nam;
        var CountName= Nam;
    };
    //---------------------------------------------
    var countName = 'Count' +  CountName ;
    var countValue = document.getElementById(countName);
    var count = countValue.value;
    //  localStorage.setItem("Count", count);
    //---------------------------------------------
    for ( let i=1 ; i<= parseInt(count); i++)
    {
        if( Nam=='Convers' || Nam=='Msg' || Nam=='UserConvers') {
            if (Nam=='Convers' )
            {
                var obji = recupConvers(i);
            }
            if (Nam=='Msg' )
            {
                var obji = recupMsg(i);
            }
            if (Nam=='UserConvers' )
            {
                var obji = recupConversUser(i);
            }
        }
        else
        {
            var obji = recupUser(i, Nam);
        };
        Add (obji,Nam);
    }
    //----------------------------------------------
};
//--------------------------------------------------------------------------
//--------------------------
function DialogSpe(Ask,Name){

//localStorage.setItem("ForContactAsk", Ask);

    if ( Name==='Contact')
    {
        var Title = 'Conversation' ;
        var IdId = 'id_ListConvers';
        var IdTab =  'UserList';
        var suff ='Convers';
        var Asking ='id_Convers';
        var linkUser='';
    }
    else
    {
        if(Name==='Convers')
        {
        var Title = 'Ajouter un utilisateur' ;
        var linkUser='<a  class=\"grey\" href=\"#\" onclick=\"ewLinki(event)\">Nouvelle Conversation</a>';
        }
        else
        {
        var Title = 'Utilisateur' ;
        var linkUser='';
        }
        var IdId = 'id_ListUser'
        var IdTab =  'UserNameList';
        var suff ='UserName';
        var Asking ='UserName';
    };
   // let content=document.getElementById(IdId).innerHTML
        var TabContent='<table>'
        +'<thead>'
        +'<tr>'
        +'<th></th>'
        +'<th><span>'+ Title +'</span></th>'
        +'</tr>'
        +'</thead>'
        +'<tbody id="'+IdTab+'">'
          ;
    var ListUserEntry = document.querySelector("#"+IdTab);
    var ListUser = indexedDB.open(NameDB);
    ListUser.onsuccess = ev => {
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      //  ListUserEntry.innerHTML = '';
        //--------------------------------------
        var CountNoContact =0;
        let dbListUser = ev.target.result;
        var NameDbConvers = NameDB+suff;
        const transactions = dbListUser.transaction(NameDbConvers, 'readwrite');
        const objectStores = transactions.objectStore(NameDbConvers);
        var index = objectStores.index(Asking);
        //localStorage.setItem("LastUser", "");
        index.openCursor().onsuccess = function (event)
        {//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
            var cursor = event.target.result;
            if (cursor)
            {
                if ( Name === 'User' && cursor.value.ContactStatu === '1' ){}
                else
                {
                    if ( Name=== 'User' || Name=== 'Convers' )
                    {
                        if (Name=== 'User') {
                            if (cursor.value.StatuUserName == 1) {
                                var puceStatu = '<span class="green">●</span>';
                            } else {
                                var puceStatu = '<span class="grey">●</span>';
                            }
                            CountNoContact = CountNoContact + 1;
                            var aReq = '<div id=\"divConvers' + CountNoContact + '\"><form>  '
                                + ' <input type=\"Hidden\" id=\"Contact_Msg' + CountNoContact + '\" name=\"Contact_Msg\"  required pattern=\"[a-zA-Z0-9 ]\"   value=\"' + cursor.value.UserName + '\" >'
                                + '</form>' + puceStatu;
                            var IdaReq = cursor.value.UserName + '<a class="linkPlus" href=\"#\" onclick=\" linky(event,' + CountNoContact + ',0)\">' + '<b >+</b></a></div>';
                        }
                        else
                        {

                            var DbUserConvers = NameDB + 'UserConvers';
                            const transactiond = dbListUser.transaction(DbUserConvers  , 'readwrite');
                            const objectStored = transactiond.objectStore(DbUserConvers);
                            var indexed = objectStored.index('id_Convers');
                            var DBuserConvers = cursor.value.UserName+"";

                            indexed.openCursor(Ask+"").onsuccess = function (eventi)
                            {//"""""""""""""""""""""""""""""""""""""""""
                                localStorage.setItem("Opening", "Opening");
                                var cursord = eventi.target.result;

                                if (cursord) {
                                    var DBuser = cursord.value.id_User+"";
                                    var DBuserConvers = cursor.value.UserName+"";

                                    localStorage.setItem("Open1", DBuser);
                                    localStorage.setItem("Open2", DBuserConvers);

                                    if(DBuser == DBuserConvers )
                                    {
                                        localStorage.setItem(DBuserConvers+Ask+"", "b");
                                    }else
                                    {
                                        localStorage.setItem(DBuserConvers+Ask+"", "a");
                                    }
                                    //-----------------------------------------------------------------
                                    cursord.continue();
                                    //-----------------------------------------------------------------
                                }
                            }

                            var HeyForContact = localStorage.getItem(DBuserConvers+Ask+"", "a");
                            if(HeyForContact == "a")
                            {
                                 if (cursor.value.StatuUserName == 1)
                                     {
                                    var puceStatu = '<span class="green">●</span>';
                                     }
                                 else
                                     {
                                    var puceStatu = '<span class="grey">●</span>';
                                     }
                            CountNoContact = CountNoContact + 1;
                            var aReq = '<div id=\"divConvers' + CountNoContact + '\"><form>  '
                                + ' <input type=\"Hidden\" id=\"Contact_Msg' + CountNoContact + '\" name=\"Contact_Msg\"  required pattern=\"[a-zA-Z0-9 ]\"   value=\"' + cursor.value.UserName + '\" >'
                                + '</form>' + puceStatu;
                            var IdaReq = cursor.value.UserName + '<a class="linkPlus" href=\"#\" onclick=\" linky(event,' + CountNoContact +','+ Ask+ ')\">' + '<b >+</b></a></div>';
                            }

                            else
                            {
                                var aReq='';
                                var IdaReq ='';
                            }
                        }
                    }
                    else
                    {
                        if( typeof cursor.value.Name_Convers == 'number'|| cursor.value.StatuConvers == 'Edit'){
                            var aReq ='';
                            var IdaReq='';
                        }
                        else
                        {
                        var aReq = '<a  class=\"grey\" href=\"#\" onclick=\" linki(event,' + cursor.value.id_Convers + ')\">';
                        var IdaReq = cursor.value.Name_Convers + '</a>';
                        }
                    }
                    TabContent =TabContent+ '<tr><td>'
                        +  aReq
                        + IdaReq
                        + '</td></tr>';
                   // var tableRow = document.createElement('tr');
                   /* tableRow.innerHTML = '<td>'
                        +  aReq
                        + IdaReq
                        + '</td>';
                    ListUserEntry.appendChild(tableRow);*/
                }
                //-----------------------------------------------------------------
                cursor.continue();
                //-----------------------------------------------------------------
            }
            else {
                let content=document.getElementById(IdId).innerHTML=TabContent
                    +'</tbody>'
                    +'</table><br/>'+linkUser;
            }
        }//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
    }
}
//***********************************************************************************//


function demet(idConvers) {
    localStorage.setItem("Key", idConvers);

    var Form = '<form id="msgForm" onsubmit="validationForm();return false" method="POST">  '
        + ' <input type="Hidden" id="id_Convers" name="id_Convers"  required pattern="[a-zA-Z0-9 ]*"  maxlength="10" value="' + idConvers + '" >'
        + ' <input type="Hidden" id="Contact_Msg" name="Contact_Msg"  required pattern="[a-zA-Z0-9 ]*"  maxlength="10" value="' + TrueUserName + '" >'
        + ' <textarea row="10" cols="50" id="Msg_Msg" name="Msg_Msg"  required  minlength="1" maxlength="250"  ></textarea><br/>'
        + ' <input type="submit" id="EDIT" value="ENVOYER" > '
        + ' </form> ';
    let contenti=document.getElementById("discussEnter").innerHTML=Form;
}
function lemet(idConvers){
    var tab='<br/><table>'
        +'<thead>'
        +'<tr>'
        +'<th></th>'
        +'<th></th>'
        +'<th></th>'
        +'</tr>'
        +'</thead>'
        +'<tbody id="ConversTab">';
    var ListUserEntry = document.querySelector("#ConversTab");
    var ListUser = indexedDB.open(NameDB);
    ListUser.onsuccess = ev =>
    {/////////////////////////////////////////////////////////////////////////////////

        //-----------------------------------------------
        var dbListUser = ev.target.result;
        //-----------------------------------------------
        //-----------------------------------------------
        var NameDbNameListy = NameDB + 'Convers';
        const transactionuy = dbListUser.transaction(NameDbNameListy, 'readwrite');
        const objectStoreuy = transactionuy.objectStore(NameDbNameListy);
        var indext = objectStoreuy.index('id_Convers',"next");
        indext.openCursor(idConvers).onsuccess = function (eventu) {//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
            var cursoru = eventu.target.result;

            if (cursoru) {
                var UserConv = cursoru.value.Name_Convers;
                let content = document.getElementById("UserConv").innerHTML = '<h3>' +  UserConv +'</h3>';
                //-----------------------------------------------------------------
                cursoru.continue();
                //-----------------------------------------------------------------
            } else {

            }
        }
        ////////////////////////////////////////////////////
        var NameDbNameList = NameDB + 'Msg';
        const transaction = dbListUser.transaction(NameDbNameList, 'readwrite');
        const objectStore = transaction.objectStore(NameDbNameList);
        var index = objectStore.index('Id_Msg',"next");
        index.openCursor().onsuccess = function (event)
        {//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
            var cursor = event.target.result;

            if (cursor) {
                if(cursor.value.Contact_Msg === 'undefined' || typeof cursor.value.Contact_Msg == 'number' ){}
                else {
                    if(idConvers === cursor.value.id_Convers) {
                        if (cursor.value.Contact_Msg === TrueUserName) {
                            var LeftTab = '';
                            var RightTab = '<b>' + TrueUserName + '</b>';
                        } else {
                            var LeftTab = '<b>' + cursor.value.Contact_Msg + '</b>';
                            var RightTab = '';
                        }

                    var tableRow = document.createElement('tr');
                    tab = tab + '<tr></tR><td>' + LeftTab + '</td>'
                        + '<td>'
                        + cursor.value.Msg_Msg
                        + '</td>'
                        + '<td>' + RightTab + '</td></tr>'
                    ;
                    }
                }
                //-----------------------------------------------------------------
                cursor.continue();
                //-----------------------------------------------------------------
            } else {
                let content=document.getElementById("Convers").innerHTML=tab
                    +'</tbody>'
                    +'</table>'+"";
            }
        }//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    }///////////////////////////////////////////////////////////////////////////////
}
//********************************************************************************//
function emet(idConvers){
    demet(idConvers);
    lemet(idConvers);
}
//********************************************************************************//
function validationForm(){

    let lContact_Msg = 'Contact_Msg';//
    let lDoc_Get_El_Contact_Msg = document.getElementById(lContact_Msg);
    let Contact_Msg = lDoc_Get_El_Contact_Msg.value;
    localStorage.setItem("Contact_Msg", Contact_Msg);
    // document.getElementById(id_Montant).innerHTML='';
    //-----------
    let lMsg_Msg='Msg_Msg';//
    let lDoc_Get_El_Msg_Msg=document.getElementById(lMsg_Msg);
    let Msg_Msg= lDoc_Get_El_Msg_Msg.value;
    localStorage.setItem("Msg_Msg", Msg_Msg);
    // document.getElementById(id_Comment).innerHTML='';
    //-----------
    let lid_Convers='id_Convers';//
    let lDoc_Get_El_id_Convers=document.getElementById(lid_Convers);
    let id_Convers = lDoc_Get_El_id_Convers.value;
    localStorage.setItem("id_Convers", id_Convers);
    // document.getElementById(id_Comment).innerHTML='';
    //-----------
    Id_Msg = parseInt(Math.round((new Date()).getTime()/100))+"";
    // id_Msg = id_Msg +"";
    //-----------
    let object=
        {
            IdTemp_Msg: Id_Msg,
            Contact_Msg: Contact_Msg,
            Msg_Msg: Msg_Msg +"",
            Date_Msg: 'Nope',
            Id_Msg: 'Nope',
            id_Convers: id_Convers,
            Statut_Msg: 'Edit'
            //------------------------------------------------------------*/
        };
    Add(object,'Msg');
    //----------------------------------------
    new emet(id_Convers);
    // }); version EDITxx
}
//********************************************************************************//
function MAJMsg() {

    var MajUser = indexedDB.open(NameDB);
    MajUser.onsuccess = ev => {
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //-------------------------------------------------------------------------
        var dbMajUser = ev.target.result;
        var transaction = dbMajUser.transaction(NameDB + 'Msg', 'readwrite');
        var objectStore = transaction.objectStore(NameDB + 'Msg');
        var index = objectStore.index('Statut_Msg');
        index.openCursor('Edit').onsuccess = function (event)
        {//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
            var cursori = event.target.result;
            if (cursori) {
                var Msg_Msg = cursori.value.Msg_Msg;
                var Contact_Msg = cursori.value.Contact_Msg;
                var id_Convers = cursori.value.id_Convers;
                var IdTemp_Msg = cursori.value.IdTemp_Msg;
                //localStorage.setItem("IdTemp_Msg", IdTemp_Msg);
                const requesti = new XMLHttpRequest();
                const requestData = `
                             & Msg_Msg=${Msg_Msg}
                             & Contact_Msg=${Contact_Msg}
                             & id_Convers=${id_Convers}
                             & IdTemp_Msg=${IdTemp_Msg}
                               `
                var postrequest = 'php/edit.php?' +
                    'Msg_Msg=' + Msg_Msg +
                    '&Contact_Msg=' + Contact_Msg +
                    '&id_Convers=' + id_Convers +
                    '&IdTemp_Msg=' + IdTemp_Msg
                ;
                requesti.open("GET", postrequest, true);
                requesti.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                requesti.send(requestData);
                ///--NOTIFICATION----------------------------------
                if (window.Notification && window.Notification !== 'denied') {
                    Notification.requestPermission(perm => {
                        if (perm === 'granted') {
                            const notif = new Notification('Envoie')
                        } else {
                        }
                    })
                }
                //--------------------------------------------------
                var data =
                    {
                        IdTemp_Msg: cursori.value.IdTemp_Msg,
                        Msg_Msg: cursori.value.Msg_Msg,
                        Contact_Msg: cursori.value.Contact_Msg,
                        id_Convers: cursori.value.id_Convers,
                        Statut_Msg: 'Current',
                        Date_Msg: 'Nope',
                        Id_Msg: 'Nope',
                        //--------------------------------------------------
                    };
                var update = objectStore.put(data);
                //--------------------------------------------------------------------------------------
                cursori.continue();
                //--------------------------------------------------------------------------------------
            } else {
            }
        }//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    }
}
//********************************************************************************//
function NewConvers(ContactUserName, IdConvers){

    let idContactConvers = "Contact_Msg"+ContactUserName;//
    let Doc_Get_El_ContactConvers = document.getElementById(idContactConvers);
    let ContactConvers= Doc_Get_El_ContactConvers.value;
    //localStorage.setItem("ContactConvers", ContactConvers);

    if(IdConvers===0 || IdConvers==='0' )
    {
        var id_Convers = parseInt(Math.round((new Date()).getTime() / 100)) + "";
    }
    else
    {
        var id_Convers = IdConvers;
    }
    var id_Convers1 = parseInt(Math.round((new Date()).getTime()/100))+"";
    var id_Convers2 = parseInt(Math.round(((new Date()).getTime()/100)+1))+"";
    //DEBUG
    /*
    localStorage.setItem("TempConvers", ContactConvers+"");
    localStorage.setItem("StatuConvers", "Edit");
    localStorage.setItem("Id_ConversConvers", id_Convers+"");   
    localStorage.setItem("Nb_ContactConvers", "2");
    localStorage.setItem("Nb_MsgConvers", "0");
    */
    let idInitEntry= "divConvers"+ContactUserName;//
    let Doc_Get_El_idInitEntre = document.getElementById(idInitEntry);
    Doc_Get_El_idInitEntre.innerHTML ='';

    let object=
        {
            IdTemp_Convers : id_Convers,
            Name_Convers : ContactConvers,
            StatuConvers: "Edit",
            id_Convers: id_Convers+"",
            Nb_Contact: "2",
            Nb_Msg: "0",
            //------------------------------------------------------------*/
        };
    Add(object,'Convers');

    let object1=
        {
            IdTemp_UserConvers : id_Convers1+"",
            id_User : TrueUserName+"",
            id_Convers: id_Convers+"",
            StatuUserConvers: "Edit",
            id_UserConvers: id_Convers1+""
            //------------------------------------------------------------*/
        };
   Add(object1,'UserConvers');
    let object2=
        {
            IdTemp_UserConvers : id_Convers2 + "",
            id_User : ContactConvers+"",
            id_Convers: id_Convers+"",
            StatuUserConvers: "Edit",
            id_UserConvers: id_Convers2 +""
            //------------------------------------------------------------*/
        };
       Add(object2,'UserConvers');
    //----------------------------------------
    //new emet(id_Convers);
   new DialogSpe(id_Convers,'Convers')

}
//********************************************************************************//
function MajConvers() {

    var MajConvers = indexedDB.open(NameDB);
    MajConvers.onsuccess = ev => {
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //-----------------------------------------------
        var dbMajUser = ev.target.result;
        var transactiony = dbMajUser.transaction(NameDB + 'Convers', 'readwrite');
        var objectStorey = transactiony.objectStore(NameDB + 'Convers');
        var indexy = objectStorey.index('StatuConvers');
        indexy.openCursor('Edit').onsuccess = function (event) {//"""""""""""""""""""""""""""""""""""""""""""""""
            var cursory = event.target.result;
            if (cursory) {
                var IdTemp_Conversu = cursory.value.IdTemp_Convers;
                var StatuConversu = cursory.value.StatuConvers;
                var id_Conversu = cursory.value.id_Convers;
                var Nb_Contactu = cursory.value.Nb_Contact;
                var Nb_Msgu = cursory.value.Nb_Msg;
                var ConversName = cursory.value.Name_Convers;

                const requesty = new XMLHttpRequest();
                const requestDatay = `
                             & IdTemp_Convers=${IdTemp_Conversu}
                             & StatuConvers=${StatuConversu}
                             & id_Convers=${id_Conversu}
                             & Nb_Contact=${Nb_Contactu}
                             & Nb_Msg=${Nb_Msgu}
                               `
                var postrequesty = 'php/editConvers.php?' +
                    'IdTemp_Convers=' + IdTemp_Conversu +
                    '&StatuConvers=' + StatuConversu +
                    '&id_Convers=' + id_Conversu +
                    '&Nb_Contact=' + Nb_Contactu +
                    '&Nb_Msg=' + Nb_Msgu
                ;
                 //DEBUG-------------------------------------------------------------------
                /*
                 localStorage.setItem("MajIdTemp_Convers", IdTemp_Convers+"");
                 localStorage.setItem("MajStatuConvers", StatuConvers + "");
                 localStorage.setItem("Majid_Convers", id_Convers+"");
                 localStorage.setItem("MajNb_Contact", Nb_Contact +"");
                 localStorage.setItem("MajNb_Msg", Nb_Msg+"");
                 */
                //-------------------------------------------------------------------------
                requesty.open("GET", postrequesty, true);
                requesty.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                requesty.send(requestDatay);

                var datay =
                    {

                        IdTemp_Convers: IdTemp_Conversu,
                        Name_Convers : ConversName,
                        StatuConvers: StatuConversu,
                        id_Convers: id_Conversu,
                        Nb_Contact: Nb_Contactu,
                        Nb_Msg: Nb_Msgu,

                        //-------------------------------------------------------------------
                    };
                var update = objectStorey.put(datay);
                //---------------------------------------------------------------------------
                cursory.continue();
                //---------------------------------------------------------------------------
            } else {
            }
        }//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

        var transactionei = dbMajUser.transaction(NameDB + 'UserConvers', 'readwrite');
        var objectStorei = transactionei.objectStore(NameDB + 'UserConvers');
        var indexei = objectStorei.index('StatuUserConvers');
        indexei.openCursor('Edit').onsuccess = function (event)
        {//"""""""""""""""""""""""""""""""""""""""""""""""
            var cursorei = event.target.result;
            if (cursorei) {

                var IdTemp_UserConvers = cursorei.value.IdTemp_UserConvers;
                var StatuUserConvers = cursorei.value.StatuUserConvers;
                var id_Conversi = cursorei.value.id_Convers+"";
                var id_UserConvers = cursorei.value.id_UserConvers;
                var id_User = cursorei.value.id_User;

                const requestei = new XMLHttpRequest();
                const requestDataei = `
                             & id_User=${id_User}
                             & IdTemp_UserConvers=${IdTemp_UserConvers}
                             & StatuUserConvers=${StatuUserConvers}
                             & id_Convers=${id_Conversi}
                             & id_UserConvers=${id_UserConvers}
                               `
                var postrequestei = 'php/editUserConvers.php?' +
                    '&id_User=' + id_User +
                    '&IdTemp_UserConvers=' + IdTemp_UserConvers +
                    '&StatuUserConvers=' + StatuUserConvers +
                    '&id_Convers=' + id_Conversi +
                    '&id_UserConvers=' + id_UserConvers
                           ;
                //DEBUG-------------------------------------------------------------------
                localStorage.setItem("MajUserIdUser", id_User);
                localStorage.setItem("Majid_Convers", id_Conversi);
                //DEBUG-------------------------------------------------------------------
                requestei.open("GET", postrequestei, true);
                requestei.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                requestei.send(requestDataei);
                var dataei =
                    {
                        IdTemp_UserConvers: cursorei.value.IdTemp_UserConvers,
                        StatuUserConvers: 'Current',
                        id_Convers: id_Conversi,
                        id_UserConvers: cursorei.value.id_UserConvers,
                        id_User: cursorei.value.id_User,
                        //-------------------------------------------------------------------
                    };
                var updatei = objectStorei.put(dataei);
                //---------------------------------------------------------------------------
                cursorei.continue();
                //---------------------------------------------------------------------------
            } else {}
        }//""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
    }
}
//********************************************************************************//