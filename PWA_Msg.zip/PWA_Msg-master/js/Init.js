//--------------------------------------------------------------------------
//                      Initialisation du contenu
//--------------------------------------------------------------------------

InitListUser('UserName');
InitListUser('Contact');

InitListUser('Convers');
InitListUser('UserConvers');
InitListUser('Msg');

InitListUser('TrueContact');
DialogSpe('','Contact');
DialogSpe('','User');

localStorage.setItem("Key","none");// pas de conversation ouverte



//--------------------------------------------------------------------------
//                      Mise a jour continu du contenu
//--------------------------------------------------------------------------
/*
let linit ;
function initcontent(){
    clearInterval(linit);
    if (navigator.onLine)
    {
        MAJMsg();
        MajConvers();
        showmsg();
        showConvers();
        showUserConvers();
        var varif=localStorage.getItem("Key");
        if (varif === "none"){}
        else {

            lemet(varif);
            DialogSpe(varif,'Convers')
        }
    }
    linit = setInterval( initcontent,5000)
}
*/

//---------------------------------------------------------

setInterval(() => {
//-------------
    if (navigator.onLine)
    {
        MAJMsg();
        MajConvers();
        showmsg();
        showConvers();
        showUserConvers();
        var varif=localStorage.getItem("Key");
        if (varif === "none"){}
        else {
            InitListUser('TrueContact');
            lemet(varif);

        }
        DialogSpe('','Contact');
    }
///-------------
}, 2500);
setInterval(() => {
//-------------
    if (navigator.onLine)
    {
        MAJMsg();
        showmsg();
        var varif=localStorage.getItem("Key");
        if (varif === "none"){}
        else {
            lemet(varif);
        }
    }
///-------------
}, 500);

//linit = setInterval( initcontent,5000)
//---------------------------------------------------------
///--------------------------------------------------------