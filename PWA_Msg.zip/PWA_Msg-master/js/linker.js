//-------------------------------------------------------------------------------


function linki(f, IdKey){

    f = f || window.event;
    f.preventDefault();

    let k =document.getElementById("Convers").innerHTML='';
    new emet(IdKey);
    new DialogSpe(IdKey,'Convers');
    //let g =document.getElementById("id_main").innerHTML='';

    //  new Get(Key);

}
function linky(f, Key,IdConvers){

    f = f || window.event;
    f.preventDefault();
    var id_Convers = parseInt(Math.round((new Date()).getTime()/100))+"";

    localStorage.setItem("NewTempConvers", Key);
     //DEBUG
    let idContactConvers = "Contact_Msg"+Key;//
    let Doc_Get_El_ContactConvers = document.getElementById(idContactConvers);
    let ContactConvers= Doc_Get_El_ContactConvers.value;
    localStorage.setItem("NewContactConvers", ContactConvers);

   let g =document.getElementById("Convers").innerHTML='';
   new NewConvers(Key,IdConvers);
    new emet(IdConvers);
    localStorage.setItem("Key", IdConvers);
    //let g =document.getElementById("id_main").innerHTML='';

    //  new Get(Key);

}
function validationFormLink(f){

    f = f || window.event;
    f.preventDefault();

    let k =document.getElementById("Convers").innerHTML='';
    new validationForm();
    //let g =document.getElementById("id_main").innerHTML='';

    //  new Get(Key);

}
function ewLinki(f){

    f = f || window.event;
    f.preventDefault();

    InitListUser('UserName');
    InitListUser('Contact');

    InitListUser('Convers');
    InitListUser('UserConvers');
    InitListUser('Msg');

    InitListUser('TrueContact');
    DialogSpe('','Contact');
    DialogSpe('','User');

    localStorage.setItem("Key","none");// pas de conversation ouverte
    //let g =document.getElementById("id_main").innerHTML='';

    //  new Get(Key);

}
//-------------------------------------------------------------------------------
/*
var Request_Id=document.getElementById("id_Request");
   Id_Request=Request_Id.value;
 if (Id_Request == 'Nope' || Id_Request == 'Rad' )
  {
    if ( Id_Request == 'Rad' ){Rad();}
  }
else
  {
Get(Id_Request);
   };
   */
//-------------------------------------------------------------------------------