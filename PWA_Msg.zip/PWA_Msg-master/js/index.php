<?php

header('Location: https://jeanritter.alwaysdata.net/SynChat/index.php');
?>